
return function(center, surface) -- small dual splitter
    local ce = surface.create_entity --save typing
    local fN = game.forces.neutral
    local direct = defines.direction

    ce{name="fast-transport-belt", position={center.x + (1.0), center.y + (-1.0)}, force=game.forces.neutral}
    ce{name="fast-splitter", position={center.x + (0.0), center.y + (-0.5)}, direction=defines.direction.east, force=game.forces.neutral}
    ce{name="fast-transport-belt", position={center.x + (-2.0), center.y + (1.0)}, direction=defines.direction.east, force=game.forces.neutral}
    ce{name="fast-transport-belt", position={center.x + (1.0), center.y + (0.0)}, direction=defines.direction.east, force=game.forces.neutral}
    ce{name="fast-transport-belt", position={center.x + (1.0), center.y + (1.0)}, direction=defines.direction.east, force=game.forces.neutral}
    ce{name="fast-transport-belt", position={center.x + (2.0), center.y + (1.0)}, direction=defines.direction.east, force=game.forces.neutral}

end
